-- liquibase formatted sql

-- changeset omarbek:1682419453327-1

create table FinDocApplication
(
    FinDoc_IDREF int not null,
    Application_IDREF int not null,
    constraint pk_FinDocApplication primary key (FinDoc_IDREF, Application_IDREF)
);