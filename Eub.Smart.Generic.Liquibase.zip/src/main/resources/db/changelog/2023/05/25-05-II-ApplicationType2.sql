-- liquibase formatted sql

-- changeset Sunnatilla:1684314470780-2

INSERT INTO ApplicationType (ApplicationType_ID, ApplicationGroup_IDREF,  ApplicationType_Title, Term_OUTREF, OfferCallback, Priority, ApplicationFormType_IDREF, Knp_IDREF, KnpText, IsActive, LogoPath)
VALUES ('AFER', 'LOAN', 'Полное досрочное погашение', null, 0, 1, 1001, null, null, 0, null);