
INSERT INTO ApplicationType (ApplicationType_ID, ApplicationGroup_IDREF,  ApplicationType_Title, Term_OUTREF, OfferCallback, Priority, ApplicationFormType_IDREF, Knp_IDREF, KnpText, IsActive, LogoPath)
VALUES ('REPA', 'LOAN', 'Частично досрочное погашение', null, 0, 1, 1001, null, null, 0, null);