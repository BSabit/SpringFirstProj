-- liquibase formatted sql

-- changeset daulet:1684314470779-1

INSERT INTO Term (Term_RU, Desc_RU, Term_KZ, Desc_KZ, Term_EN, Desc_EN, Code)
VALUES ('repayment_sms_success', 'Полное досрочное погашение успешно осуществлено. Ваш кредит закрыт.',
'repayment_sms_success', 'Несиені мерзімінен бұрын толық өтеу сәтті орындалды. Несиеңіз жабылды.',
'repayment_sms_success', 'content',
'repayment_sms_success');

INSERT INTO Term (Term_RU, Desc_RU, Term_KZ, Desc_KZ, Term_EN, Desc_EN, Code)
VALUES ('repayment_sms_fail', 'Полное досрочное погашение не было осуществлено. Повторите попытку позже.',
'repayment_sms_fail', 'Несиені мерзімінен бұрын толық өтеу орындалған жоқ. Кейінірек қайталап көріңіз.',
'repayment_sms_fail', 'content',
'repayment_sms_fail');