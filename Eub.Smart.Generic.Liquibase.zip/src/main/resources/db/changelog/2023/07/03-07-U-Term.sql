-- liquibase formatted sql

-- changeset zbek:1688361771549-1

UPDATE Term
SET Desc_KZ = N'Мерзімінен бұрын жартылай өтеу туралы өтініш қабылданды. Өзгерістер бір күн ішінде күшіне енеді.'
WHERE Code = 'partial_repayment_sms_success';

UPDATE Term
SET Desc_KZ = N'Мерзімінен бұрын жартылай өтеу барысында қателік орын алды. Қайта қайталап көруіңізді сұраймыз.'
WHERE Code = 'partial_repayment_sms_fail';