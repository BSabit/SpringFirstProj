-- liquibase formatted sql

-- changeset zbek:1688201482642-1

INSERT INTO Term
(Term_RU, Desc_RU, Term_KZ, Desc_KZ, Term_EN, Desc_EN, Code)
VALUES ('partial_repayment_sms_success_ru','Заявка на частичное досрочное погашение принята. Изменения вступят в течение суток.',
        'partial_repayment_sms_success_kz',N'Ішінара мерзімінен бұрын өтеу туралы өтініш қабылданды. Өзгерістер бір күн ішінде күшіне енеді.',
        'partial_repayment_sms_success_en','Application for partial early repayment accepted. The changes will take effect within a day.',
        'partial_repayment_sms_success');

INSERT INTO Term
(Term_RU, Desc_RU, Term_KZ, Desc_KZ, Term_EN, Desc_EN, Code)
VALUES ('partial_repayment_sms_fail_ru','Возникла ошибка при выполнении частичного досрочного погашения. Просим попробовать снова.',
        'partial_repayment_sms_fail_kz',N'Ішінара мерзімінен бұрын өтеуді орындау кезінде қате орын алды. Қайталап көріңіз',
        'partial_repayment_sms_fail_en','An error occurred while performing a partial early repayment. Please try again',
        'partial_repayment_sms_fail');
