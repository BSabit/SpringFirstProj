-- liquibase formatted sql

-- changeset zh_bexultan:1688361771551-1

ALTER TABLE WhiteListAuthorization ADD SmsHash NVARCHAR(56) NOT NULL;