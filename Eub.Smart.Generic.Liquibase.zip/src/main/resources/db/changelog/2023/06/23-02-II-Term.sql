-- liquibase formatted sql

-- changeset daulet:1687520482193-2

INSERT INTO Term (Term_RU, Desc_RU, Term_KZ, Desc_KZ, Term_EN, Desc_EN, Code)
VALUES ('passcode_error_short_ru','Неверный код',
'passcode_error_short_kz',N'Қате код',
'passcode_error_short_en','Invalid code',
'passcode_err_short');

INSERT INTO Term (Term_RU, Desc_RU, Term_KZ, Desc_KZ, Term_EN, Desc_EN, Code)
VALUES ('passcode_error_ru','Неверный код. Осталось попыток: %d',
'passcode_error_kz',N'Қате код. Қалған әрекеттер: %d',
'passcode_error_en','Invalid code. Attempts left: %d',
'passcode_error');

INSERT INTO Term (Term_RU, Desc_RU, Term_KZ, Desc_KZ, Term_EN, Desc_EN, Code)
VALUES ('define_route_error_msg_ru','Ой, пришлось вас разлогинить',
'define_route_error_msg_kz',N'Ой, сізді жүйеден шығардық',
'define_route_error_msg_en','Oh, we had to log you out',
'define_route_error_msg');

INSERT INTO Term (Term_RU, Desc_RU, Term_KZ, Desc_KZ, Term_EN, Desc_EN, Code)
VALUES ('define_route_error_desc_ru','Сделали это в целях безопасности. Пожалуйста войдите заново',
'define_route_error_desc_kz',N'Біз мұны қауіпсіздік мақсатында жасадық. Қайтадан кіріңіз',
'define_route_error_desc_en','We did it in security aims. Please, log in',
'define_route_error_desc');

INSERT INTO Term (Term_RU, Desc_RU, Term_KZ, Desc_KZ, Term_EN, Desc_EN, Code)
VALUES ('define_route_button_text_ru','Войти заново',
'define_route_button_text_kz',N'Қайтадан кіру',
'define_route_button_text_en','Log in',
'define_route_button_text');

INSERT INTO Term (Term_RU, Desc_RU, Term_KZ, Desc_KZ, Term_EN, Desc_EN, Code)
VALUES ('call_bank_error_msg_ru','Доступ заблокирован',
'call_bank_error_msg_kz',N'Кіру бұғатталған',
'call_bank_error_msg_en','Access blocked',
'call_bank_error_msg');

INSERT INTO Term (Term_RU, Desc_RU, Term_KZ, Desc_KZ, Term_EN, Desc_EN, Code)
VALUES ('call_bank_error_desc_ru','Мы заблокировали аккаунт в целях безопасности. Позвоните в службу поддержки для подтверждения личности, а потом восстановите пароль',
'call_bank_error_desc_kz',N'Біз қауіпсіздік мақсатында есептік жазбаны бұғаттадық. Жеке басыңызды растау үшін қолдау қызметіне қоңырау шалыңыз, содан кейін құпия сөзді қалпына келтіріңіз',
'call_bank_error_desc_en','We blocked your account in security aims. Contact support to confirm your identity and then reset pass-code',
'call_bank_error_desc');

INSERT INTO Term (Term_RU, Desc_RU, Term_KZ, Desc_KZ, Term_EN, Desc_EN, Code)
VALUES ('call_bank_button_text_ru','Обратиться в поддержку',
'call_bank_button_text_kz',N'Қолдау қызметіне хабарласу',
'call_bank_button_text_en','Contact support',
'call_bank_button_text');