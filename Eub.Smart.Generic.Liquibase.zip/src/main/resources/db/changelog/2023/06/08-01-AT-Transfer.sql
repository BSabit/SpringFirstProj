-- liquibase formatted sql

-- changeset alibi:1686220138961-1

ALTER TABLE Transfer
    ADD Receiver_Amount money