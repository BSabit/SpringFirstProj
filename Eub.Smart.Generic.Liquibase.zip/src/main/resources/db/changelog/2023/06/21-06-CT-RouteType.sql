-- liquibase formatted sql

-- changeset Abekmat:1687353579229-1

CREATE TABLE dbo.[RouteType]
(
	[RouteType_ID]       		nchar(4) NOT NULL ,
	[RouteType_Title] 		    varchar(70) NOT NULL ,
	CONSTRAINT [RouteType_PK] PRIMARY KEY NONCLUSTERED ([RouteType_ID] ASC)
);