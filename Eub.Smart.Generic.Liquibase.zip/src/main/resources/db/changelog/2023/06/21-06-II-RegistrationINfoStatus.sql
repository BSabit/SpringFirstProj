-- liquibase formatted sql

-- changeset Abekmat:1687353579229-31

INSERT INTO dbo.[RegistrationINfoStatus] ([RegistrationINfoStatus_ID], [RegistrationINfoStatus_Title])
VALUES
    ('CRUS', 'Пользователь успешно создан'),
    ('FAIL', 'Ошибка при создании пользователья'),
    ('FGBD', 'Ошибка при обращений в государственную базу данных'),
    ('FDOC', 'Пользователь создан, но документ не получилось сохранить');