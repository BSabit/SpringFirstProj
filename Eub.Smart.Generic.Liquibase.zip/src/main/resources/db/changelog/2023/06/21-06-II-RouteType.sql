-- liquibase formatted sql

-- changeset Abekmat:1687353579229-23

INSERT INTO dbo.RouteType(RouteType_ID, RouteType_Title)
VALUES
    ('RBYB', 'Восстановление по биометрии'),
    ('RBYP', 'Восстановление по продукту'),
    ('REGR', 'Регистрация'),
    ('WHLS', 'Белый список'),
    ('NTFC', 'Незавершенный время жизни');