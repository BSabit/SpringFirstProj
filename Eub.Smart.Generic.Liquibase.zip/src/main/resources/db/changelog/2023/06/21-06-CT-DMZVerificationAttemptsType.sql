-- liquibase formatted sql

-- changeset Abekmat:1687353579229-8

CREATE TABLE dbo.[DMZVerificationAttemptsType]
(
	[DMZVerificationAttemptsType_ID]     	nvarchar(4) NOT NULL,
	[DMZVerificationAttemptsType_Title] 	varchar(255) NOT NULL,
	CONSTRAINT [DMZVerificationAttemptsType_PK] PRIMARY KEY CLUSTERED ([DMZVerificationAttemptsType_ID] ASC)
);