-- liquibase formatted sql

-- changeset Abekmat:1687944521328-1

INSERT INTO [DMZVerificationAttemptsType] ([DMZVerificationAttemptsType_ID], [DMZVerificationAttemptsType_Title])
VALUES
    ('ESMS','Неуспешная проверка СМС\ОТП от EGOV');