-- liquibase formatted sql

-- changeset Abekmat:1687353579229-27

INSERT INTO dbo.[RecoveryProductAccountType] ([RecoveryProductAccountType_ID],[RecoveryProductAccountType_Title])
VALUES
    ('ACCT',	'по текущему счету/депозиту'),
    ('CARD',	'по карте');