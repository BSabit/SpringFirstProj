-- liquibase formatted sql

-- changeset Abekmat:1687353579229-16

CREATE TABLE dbo.[RecoveryProduct]
(
	[RecoveryProduct_ID]							bigint IDENTITY (1, 1) NOT NULL,
	[DateCreated]									datetime NOT NULL default getDate(),
	[ProductNumber]									nvarchar(70) NOT NULL,
	[RecoveryProductAccountType_IDREF]				nchar(4) NOT NULL,
	[RecoveryProductStatus_IDREF]					nchar(4) NOT NULL,
	[iin]                           				nchar(12) NOT NULL,
	[DMZVerification_IDREF]							bigint NOT NULL,
	[Customer_OUTREF] 								varchar(255) NULL,
	[MobilePhone_OUTREF] 							varchar(255) NULL,
	[BSystem_IDREF]                                 char(4) NULL,
	CONSTRAINT [RecoveryProduct_PK] PRIMARY KEY NONCLUSTERED ([RecoveryProduct_ID] ASC),
	CONSTRAINT [FK_recoveryProduct] FOREIGN KEY (BSystem_IDREF) REFERENCES BSystem(BSystem_ID),
	CONSTRAINT [RecoveryProduct_AccountType_FK] FOREIGN KEY ([RecoveryProductAccountType_IDREF]) REFERENCES [RecoveryProductAccountType]([RecoveryProductAccountType_ID]),
	CONSTRAINT [RecoveryProduct_DMZVerification_FK] FOREIGN KEY ([DMZVerification_IDREF]) REFERENCES [DMZVerification]([DMZVerification_ID]),
	CONSTRAINT [RecoveryProduct_RecoveryProductStatus_FK] FOREIGN KEY ([RecoveryProductStatus_IDREF]) REFERENCES [RecoveryProductStatus]([RecoveryProductStatus_ID]),
);