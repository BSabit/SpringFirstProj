-- liquibase formatted sql

-- changeset YKaliyev:1687451830031-1

INSERT INTO dbo.[DMZVerificationAttemptsType] ([DMZVerificationAttemptsType_ID], [DMZVerificationAttemptsType_Title])
VALUES
    ('CSMS','Неуспешная проверка СМС\ОТП');