-- liquibase formatted sql

-- changeset Abekmat:1687353579229-13

CREATE TABLE dbo.[DMZVerificationAttempts]
(
	[DMZVerificationAttempts_ID]                bigint IDENTITY (1, 1) NOT NULL,
	[MobilePhone]                	            nchar(11) NOT NULL,
	[DMZVerificationAttemptsType_IDREF]         nvarchar(4) NOT NULL,
	[DMZVerification_IDREF]           	        bigint NOT NULL,
	[DateCreated]                             	datetime NOT NULL default getDate(),
	[PasscodeSet]                            	bit NULL default 0 ,
	CONSTRAINT [DMZVerificationAttempts_PK] PRIMARY KEY NONCLUSTERED ([DMZVerificationAttempts_ID] ASC),
	CONSTRAINT [DMZVerificationAttempts_DMZVerificationAttemptsType_FK] FOREIGN KEY ([DMZVerificationAttemptsType_IDREF]) REFERENCES [DMZVerificationAttemptsType]([DMZVerificationAttemptsType_ID]),
	CONSTRAINT [DMZVerificationAttempts_DMZVerification_FK] FOREIGN KEY ([DMZVerification_IDREF]) REFERENCES [DMZVerification]([DMZVerification_ID])
);