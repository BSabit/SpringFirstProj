-- liquibase formatted sql

-- changeset Abekmat:1687353579229-34

INSERT INTO Term (Term_RU, Desc_RU, Term_EN, Desc_EN, Term_KZ, Desc_KZ)
VALUES ('Данные не совпадают', 'Номер телефона, ИИН или номер продукта не совпадают между собой. Проверьте правильность ввода данных повторите попытку',
        'Data doesn’t match', 'Phone number, IIN or product number don’t match. Please, check you enter right data and retry',
        N'Деректер сәйкес келмейді',N'Телефон нөмірі, ЖСН немесе өнім нөмірі сәйкес келмейді. Енгізілген деректердің дұрыстығын тексеріп, қайталаңыз');

INSERT INTO Term (Term_RU, Desc_RU, Term_EN, Desc_EN, Term_KZ, Desc_KZ)
VALUES ('Продукт не активен', 'Возможно он заблокирован или закрыт. Используйте другой продук или обратитесь в поддержку банка',
    'Product INactive', 'Probably the product is expired or blocked. Please, try another product or contact bank support',
    N'Өнім белсенді емес',N'Мүмкін ол жабық немесе бұғатталған. Басқа өнімді пайдаланыңыз немесе банктің қолдау қызметіне хабарласыңыз');

INSERT INTO Term (Term_RU, Desc_RU, Term_EN, Desc_EN, Term_KZ, Desc_KZ)
VALUES ('Что-то пошло не так', 'Возникла какая-та ошибка. Пожалуйста, повторите попытку',
    'SomethINg went wrong', 'Some problem occurred. Please, retry',
    N'Қателік шықты',N'Белгісіз ақау шықты, қайталап көреңіз');
