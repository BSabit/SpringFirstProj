-- liquibase formatted sql

-- changeset Abekmat:1687353579229-37

UPDATE RecoveryProductStatus
SET Term_OUTREF = (SELECT Term_ID FROM Term WHERE Term_RU = 'Данные не совпадают')
WHERE RecoveryProductStatus.RecoveryProductStatus_ID IN
(
   'WPHE',
   'CNEW',
   'FCNF',
   'RSPE',
   'PNER',
   'CNER',
   'CNAR',
   'FMPO',
   'FPHE',
   'FPHN'
);

UPDATE RecoveryProductStatus
SET Term_OUTREF = (SELECT Term_ID FROM Term WHERE Term_RU = 'Продукт не активен')
WHERE RecoveryProductStatus.RecoveryProductStatus_ID IN
(
   'ARST',
   'FCIE',
   'FAOW',
   'ANAR',
   'ANER',
   'W4NA'
);

UPDATE RecoveryProductStatus
SET Term_OUTREF = (SELECT Term_ID FROM Term WHERE Term_RU = 'Что-то пошло не так')
WHERE RecoveryProductStatus.RecoveryProductStatus_ID = 'FALL';

