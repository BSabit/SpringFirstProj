-- liquibase formatted sql

-- changeset Abekmat:1687353579229-22

CREATE TABLE dbo.Gbdfl_Region (
    Gbdfl_Code                  char(8) NOT NULL,
    Gbdfl_Title                 nvarchar(37) NOT NULL,
    Region_IDREF                int NULL,
    CONSTRAINT FK_Gbdfl_Region_Region FOREIGN KEY (Region_IDREF) REFERENCES Region(Region_ID)
);