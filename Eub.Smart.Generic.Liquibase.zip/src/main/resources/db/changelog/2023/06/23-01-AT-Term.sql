-- liquibase formatted sql

-- changeset daulet:1687520582795-1

ALTER TABLE Term ALTER COLUMN Desc_KZ NVARCHAR(1000) COLLATE Kazakh_90_CI_AS;