-- liquibase formatted sql

-- changeset Abekmat:1687353579229-9

CREATE TABLE dbo.[RegistrationInfoStatus]
(
	[RegistrationInfoStatus_ID]      	nchar(4) NOT NULL ,
	[RegistrationInfoStatus_Title] 	    varchar(255) NOT NULL ,
	[Term_OUTREF] 					    int NULL,
	CONSTRAINT [RegistrationInfoStatus_PK] PRIMARY KEY CLUSTERED ([RegistrationInfoStatus_ID] ASC)
);