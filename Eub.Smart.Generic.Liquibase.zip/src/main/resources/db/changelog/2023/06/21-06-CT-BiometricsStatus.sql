-- liquibase formatted sql

-- changeset Abekmat:1687353579229-3

CREATE TABLE dbo.[BiometricsStatus]
(
	[BiometricsStatus_ID]    		    nchar(4) NOT NULL,
	[BiometricsStatus_Title] 		    varchar(255) NOT NULL,
	[Term_OUTREF]                       int NULL,
	CONSTRAINT [BiometricsStatus_PK] PRIMARY KEY NONCLUSTERED ([BiometricsStatus_ID] ASC)
);