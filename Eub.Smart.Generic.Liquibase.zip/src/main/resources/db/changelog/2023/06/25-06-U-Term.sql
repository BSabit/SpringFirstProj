-- liquibase formatted sql

-- changeset YKaliyev:1687453434373-1

 UPDATE Term
 SET Desc_KZ = N'Қате код'
 WHERE Term_KZ = 'passcode_error_short_kz';

 UPDATE Term
 SET Desc_KZ = N'Қате код. Қалған әрекеттер: %d'
 WHERE Term_KZ = 'passcode_error_kz';

 UPDATE Term
 SET Desc_KZ = N'Ой, сізді жүйеден шығардық'
 WHERE Term_KZ = 'define_route_error_msg_kz';

 UPDATE Term
 SET Desc_KZ = N'Біз мұны қауіпсіздік мақсатында жасадық. Қайтадан кіріңіз'
 WHERE Term_KZ = 'define_route_error_desc_kz';

 UPDATE Term
 SET Desc_KZ = N'Қайтадан кіру'
 WHERE Term_KZ = 'define_route_button_text_kz';

 UPDATE Term
 SET Desc_KZ = N'Кіру бұғатталған'
 WHERE Term_KZ = 'call_bank_error_msg_kz';

 UPDATE Term
 SET Desc_KZ = N'Біз қауіпсіздік мақсатында есептік жазбаны бұғаттадық. Жеке басыңызды растау үшін қолдау қызметіне қоңырау шалыңыз, содан кейін құпия сөзді қалпына келтіріңіз'
 WHERE Term_KZ = 'call_bank_error_desc_kz';

 UPDATE Term
 SET Desc_KZ = N'Қолдау қызметіне хабарласу'
 WHERE Term_KZ = 'call_bank_button_text_kz';

