-- liquibase formatted sql

-- changeset Abekmat:1687353579229-33

INSERT INTO [UserStatus]  (UserStatus_ID, UserStatus_Title, IsValid)
VALUES ('UDUR', 'Разблокирован по желанию пользователя', 0);