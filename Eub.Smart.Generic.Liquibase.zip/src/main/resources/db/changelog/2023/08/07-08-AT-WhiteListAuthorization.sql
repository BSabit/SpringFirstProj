-- liquibase formatted sql

-- changeset zh_bexultan:1691403199350-1

ALTER TABLE WhiteListAuthorization DROP COLUMN SmsHash;