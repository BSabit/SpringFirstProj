# Введение
- МКС для миграции базы данных
- при изменениях создавать changelog (создавать папку под каждый год-месяц)
- naming {data}-{change log number}-{operation}-{table name}.sql (EXAMPLE: 19-01-CT-USER.sql)
  - CT create table
  - AT alter table
  - U update
  - D delete
  - DT drop table
  - II insert into
  - etc.
- changelog писать в sql
- changelog id равен {current milliseconds}-{change number}  (https://currentmillis.com)
- changelog добавлять изменения в db.changelog-master.yaml
- если изменения не накатились читаем логи. проверям таблицу databasechangeloglock поле locked должно быть false

![alt text](changelog-example.png)

# Начало работы
1. git clone
2. Восстановление пакетов и компиляция: gradle build
3. VPN, доступ к тест БД

# Сборка и тестирование
TODO: опишите и покажите, как выполнить сборку кода и тесты.

# Участие
TODO: --

Если вам нужны дополнительные сведения о создании файлов сведений, ознакомьтесь со следующими [руководствами](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). Кроме того, вам, возможно, будут полезны следующие примеры файлов сведений:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)

![alt text](logic-schema/liquibase.png)